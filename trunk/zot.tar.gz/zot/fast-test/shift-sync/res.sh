more out-* | grep -E "(^\\$)|unhandled|real|SAT---|::|out|Pre-CNF|variable:|clauses:|Memory|Solved by unit propagation|Time bound" > ../result-shift-sync.txt

