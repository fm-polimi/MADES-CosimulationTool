more out-* | grep -E "(^\\$)|real|unhandled|SAT---|::|out|Pre-CNF|variable:|clauses:|Memory|Solved by unit propagation|Time bound" > ../result-lamp.txt

