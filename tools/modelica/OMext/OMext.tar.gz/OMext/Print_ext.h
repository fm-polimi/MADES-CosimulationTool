/* Header file Print_ext.h for Print_ext */

void Print_ext(double,double,double);
