#ifndef Test__H
#define Test__H
#include "modelica.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include "simulation_runtime.h"
extern "C" {
}
#endif


