/* Header file Init_ext.h for Init_ext */

void Init_ext(void);
