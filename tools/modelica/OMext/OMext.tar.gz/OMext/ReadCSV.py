import csv

# aprire il file csv
reader = csv.reader(file("./testZC_res.csv", "rb"))


j = 0
name = []
val = []

# iniziare la lettura delle righe
for row in reader:
	j = j+1
	i = 0
	# la prima riga contiene i nomie
	if j==1:
		for el in row:
			name.append(el)
			
	# verifico che sia l'ultima riga
	try:
		reader.next()
	except StopIteration:
		for el in row:
			val.append(el) 	
			
# stampa dei nomi e del valore finale
print name
print val
    



