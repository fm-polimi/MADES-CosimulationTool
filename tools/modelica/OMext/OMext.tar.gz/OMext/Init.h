#ifndef Init__H
#define Init__H
#include "modelica.h"
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#ifdef __cplusplus
extern "C" {
#endif


void _Init();

extern void Init_ext();
#ifdef __cplusplus
extern "C" {
#endif
#include "Print_ext.h"
#ifdef __cplusplus
}
#endif

#ifdef __cplusplus
}
#endif
#endif

